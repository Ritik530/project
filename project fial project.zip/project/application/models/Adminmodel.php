<?php

class Adminmodel extends CI_Model
{

  function __construct()

  {

    parent::__construct();
  }
  function dataInsert()
  {
 
    //   $i = $this->input->post('image');
    //   // $remove_type = explode(";", $imgblob);
    //   // // echo $remove_type[1];
    //   // $remove_base = explode(",", $remove_type[0]);
    //   // $final_data = $remove_base[0];
    //   // $final_data_de = base64_decode($final_data);
    //   // $image = time().'.jpg';
    //   // print_r($i);
    //   // die;
   
    // $config['upload_path'] = './images/';
    //             $config['allowed_types'] = 'gif|jpg|png';
               
    //             $this->load->library('upload', $config);

    //             if ( ! $this->upload->do_upload($i))
    //             {
    //                     $error = array('error' => $this->upload->display_errors());
    //                     print_r($error);
    //                     die;
    //                     // $this->load->view('upload_form', $error);
    //             }
    //             else
    //             {
    //                     $data = array('upload_data' => $this->upload->data());
    //                     $img = $data['upload_data']['file_name'];

    //                     // $this->load->view('upload_success', $data);
    //             }



      // $image_name = "images/" . $_FILES['image']['name'];


      // $imgblob = $this->input->post('image');
      // // echo $imgblob;
      // $remove_type = explode(";", $imgblob);
      // // echo $remove_type[1];
      // $remove_base = explode(",", $remove_type[0]);
      // $final_data = $remove_base[0];
      // $final_data_de = base64_decode($final_data);
      // $image = time().'.jpg';

      $data = array(
        'fld_id' => rand(10, 99),
        'price' => $this->input->post('add_blog_price'),
        'access' => $this->input->post('access_select'),
        'fld_url' => 'www.google.og',
        'fld_title' => $this->input->post('add_blog_name'),
        'tld_page_position' => '15',
        'shortdescription' => $this->input->post('add_blog_short'),
        'fld_description' => $this->input->post('add_blog_pageedit'),
        'fld_image' => $_FILES['image']['name'],
        'fld_status' => '1',

      );




      $this->db->insert('tbl_blog', $data);
      // print_r($dataa);
      // die;


      // file_put_contents("images/" . $image, $basedecoder);


      move_uploaded_file($_FILES['image']['tmp_name'], "images/" . $_FILES['image']['name']);
    }
  
  public function upload_image()
  {



    if (isset($_POST['image'])){
      $data = $_POST["image"];
      $image_array_1 = explode(";", $data);
      $image_array_2 = explode(",", $image_array_1[1]);
      $basedecoder = base64_decode($image_array_2[1]);
      $image = time() . '.png';
      $dataa = array(
        'fld_id' => rand(10, 99),
        'fld_image' => $image,

      );

      $this->db->insert('tbl_blog', $dataa);

      file_put_contents("images/" . $image, $basedecoder);
      return $image;


    }


  }








  // $imgblob = $this->input->post('image');
  // // echo $imgblob;
  // $remove_type = explode(";", $imgblob);
  // // echo $remove_type[1];
  // $remove_base = explode(",", $remove_type[1]);
  // $final_data = $remove_base[1];
  // $final_data_de = base64_decode($final_data);
  // $image = time() . '.png';
  // file_put_contents("images/" . $image, $final_data_de);



  //   return $image;
  // }

  function fetch_data()
  {
    $table_data = $this->db->get('tbl_blog');
    return $table_data->result();
  }


  function update_data($id)
  {
    $replace_data = array(
      'fld_id' => $id,
      'fld_title' => $this->input->post('edit_blog_name'),
      'price' => $this->input->post('edit_blog_price'),
      'access' => $this->input->post('access_select'),
      'shortdescription' => $this->input->post('edit_blog_short_description'),
      'fld_description' => $this->input->post('edit_blog_description'),
      'fld_image' => $_FILES["img"]['name']
    );
    $this->db->where("fld_id", $id);
    move_uploaded_file($_FILES['img']['tmp_name'], "images/" . $_FILES['img']['name']);

    $this->db->update('tbl_blog', $replace_data);


    // $data['page'] = 'Users/blog/page';
    // $this->load->view("includes/home",$data);






  }
  function delete_blo($checked_id)
  {
    $this->db->where_in('fld_id', $checked_id);
    return $this->db->delete('tbl_blog');
  }
  //   $data_delete = array('fld_id' => $id);
  //   $this->db->where('fld_id',$id);
  //   $query= $this->db->delete('tbl_blog', $data_delete);
  //   return true;
  // }
  // {

  //   $data_delete = array('fld_id' => $id);

  //   $this->db->where("fld_id", $id);
  //   $this->db->delete('tbl_blog', $data_delete);
  // }
  public function edit_blo($sId)
  {
    $this->db->where('fld_id', $sId);

    $query = $this->db->get('tbl_blog');
    return $query->result();
  }
}
