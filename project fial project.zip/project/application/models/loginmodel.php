<?php

class loginmodel extends CI_Model{

//    public function __construct(){
//        parent::__construct();
//        $this->load->database();
//    }


//    public function login()
//    {
//        $name=$this->input->post('fld_email');
//        return $name;
      
//    }
public function isvalidate($email,$password){
    // $q=$this->db->query("select * form tbl_admin where fld_email =$email and fld_password=$password")->get('tbl_admin');
    // if($q->num_rows()){
    //     return true;

    // }
    // else{
    //     return false;
    // }
    $q=$this->db->where([' fld_email' =>$email, 'fld_password'=> $password])->get('tbl_admin');

    if($q->num_rows()){
        return true;
    }
    else{
        return false;
    }
}
public function validate($email)
{
        $this->db->where('fld_email',$email);

        $details = $this->db->get('tbl_admin');

        return $details->result();
}




}
