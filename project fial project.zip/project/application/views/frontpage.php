<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USA Tax Services | US Expat Tax Consulting and Advisory Hong Kong</title>
</head>
<style>
    .display {
        text-align: center;
    }
</style>

<body>
    <div class="display">
        <table name="home_">
            <tr class="row1">
                <?php foreach ($table_data->result() as $row) { ?>
                    <td>
                        <form method="post" action="#">
                            <img src="<?php echo base_url(); ?>images/<?php echo $row->fld_image; ?>" width="500px" height="300px"><br>
                            <h3><?php echo $row->fld_title; ?></h3>
                            <p>$199.99</p>
                            <input type="submit" value="Buy Now">
                        </form>
                    </td>
                <?php } ?>
            </tr>
        </table>
    </div>
</body>
</html>