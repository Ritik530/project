<!-- <!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Htj.capital</title>

</head> -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Htj.capital</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

</head>


<style>
    body {
        color: #eeeaea;
        background: #F7F7F7;
        font-size: 17px;
        font-weight: 500;
        line-height: 1.471;
        font-family: Arial, Helvetica, sans-serif;
    }

    .div_main {
        width: 100%;
        /* height: 100%; */
        /* background-color: aqua; */
        position: absolute;
    }

    .right-div {
        width: 87%;
        /* height: 100%; */
        position: relative;
        background-color:  #E6E9ED;
        float: left;
    }

    .left-nav {
        width: 99.5%;
        /* height: 100%; */
        position: relative;
        float: left;
    }

    .dropdown {
        background-color: rgb(149, 63, 175);
        color: rgb(255, 255, 255);
        font-size: 18px;
        /* padding-left: 0px; */
        margin-right: 7px;
        width: 120px;
        height: 53px;


        /* margin-left: 4px; */
        padding-top: 2px;
        padding-bottom: 5px;
    }

    .dropdown:hover {
        background: rgb(61, 60, 60);
    }

    .collapse {
        padding-left: 10px;
        font-size: 30px;
    }

    #navbarDropdown {
        color: aliceblue;
    }

    #navbarNav {
        color: #000000;
    }

    #navbarDropdow {
        color: black;
        background-color: rgb(238, 131, 241);
        padding-top: 17px;
        padding-left: 17px;
        padding-bottom: 11px;
    }
  
</style>

<body>

    <div class="left-nav">
        <nav class="navbar navbar-expand-lg navbar-light bg-light" style="height: 57px;">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse mi-auto" id="navbarNav">
                <i class="fa-solid fa-bars"></i>

            </div>

            <div class="dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Admin
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown"  onchange="location = this.value;">
                    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                    <li><a class="dropdown-item" href="<?php echo base_url(); ?>Users/logout"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a></li>

                </ul>
            </div>
        </nav>


    </div>
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>

</html>