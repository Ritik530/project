<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php base_url("Assets/css/bootstrap.min.css") ?>">
    <title>Document</title>
</head>
<style>
    .login {
        background-size: cover;
        background-attachment: fixed;
        padding-top: 75px;

    }

    *,
    ::after,
    ::before {
        box-sizing: border-box;
    }


    body {
        display: block;
    }

    .main {
        width: 1000px;
        margin: 0% auto;
        display: table;
        box-shadow: 0px 0px 20px 0px rgba(44, 44, 44, 0.4);
    }

    body {
        color: #eeeaea;
        background: #5cf8de;
        font-size: 17px;
        font-weight: 500;
        line-height: 1.471;
        font-family: Arial, Helvetica, sans-serif;
    }

    .login-left {
        width: 500px;
        float: left;
        text-align: center;
        /* background-color: blue; */
        height: 500px;
        padding: 70px 50px 70px 50px;
    }

    .login-left h1 {
        color: white;
        margin-top: 8px;
        margin-bottom: 8px;
        font-size: 40px;
    }

    .login-left p {
        font-size: 19px;
        line-height: 27px;
        color: #fff;
        /* font-weight: normal; */
    }

    .login_right {
        width: 500px;
        height: 500px;
        float: right;
        position: relative;
        background-color: white;
    }


    .login .form {
        position: relative;
        padding: 50px 100px;
    }

    .animate {
        animation-duration: .5s;
        animation-timing-function: ease;
        animation-fill-mode: both;
        margin: 0px;
        border-radius: 7px;
    }

    .form {
        z-index: 30;
    }

    .form {
        top: 0px;
        width: 100%;

    }

    .content {
        margin: 0px auto;
        padding: 30px 0px 0px;
        position: relative;
        text-align: center;
        text-shadow: 0 1px 0 #fff;
        min-width: 250px;
    }

    .content .form {
        margin: 30px 0px 30px 0px;
        position: relative;
    }

    .content h1 {
        font-size: 35px;
        font-weight: 600;
        letter-spacing: -.05em;
        line-height: 30px;
        margin: 13px 0px 32px;
        color: black;
    }

    #email {
        margin-top: 30px;
        padding: 15px;
        width: 350px;
        border-radius: 10px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }

    /* #username{
    margin: 30px;
    padding: 15px;
} */
    #password {
        /* background-position: 10px -53px!important; */
        padding: 15px;
        width: 350px;
        border-radius: 10px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }

    .form_control {
        display: block;
        padding: 10px 15px 10px 15px;
        font-size: 17px;
        line-height: 1.47;

    }

    input:-internal-autofill-selected {
        appearance: menulist-button;
        background-image: none !important;
        background-color: -internal-light-dark(rgb(48, 114, 226), rgba(70, 90, 126, 0.4)) !important;
        color: -internal-light-dark(rgb(255, 255, 255), white) !important;
    }

    .main .btn {
        display: inline-block;
        margin-top: 10px;
        padding: 12px 14px 12px 14px;
        font-size: 16px;
        color: rgb(255, 255, 255);
        background-color: rgb(35, 132, 223);
        border-color: rgb(32, 213, 236);
    }

    #forget {
        margin-left: -40px;
    }

    .login-register-text {
        color: black;
        padding-top: 3px;
        font-size: 15px;
        width: 260px;
    }

    .container {
        width: 100%;
        padding: 0px;

    }

    .div_main {
        width: 100%;
        background-color: aqua;
        position: fixed;
    }
    .mgg{
        color: red;
        font-size: 13px;
        padding-left: 60px;
        position: fixed;
        margin-top: -16px;
    }
</style>


<body class="login">
    <div class="main">
        <div class="login-left" style="background: url(<?php echo base_url(); ?>Css/rkk.png);">
            <h1>Usa Tax Services</h1>
            <p>Premium Content Management</p>
        </div>
        <div class="login_right">
            <div class=" animate form">
                


                <section class="content">
                    <form method="post" action="<?php echo base_url(); ?>Users/home">


                        <h1>Login</h1>

                        <div>

                            <!-- <input type="email" name="email" id="email" class="form_control" placeholder="Email" require> -->
                            <input type="email" name="mail" id="email" class="form_control" placeholder="Enter Email" require>
                            <br>
                            <input type="password" name="pass" id="password" class="form_control" placeholder="Enter Password" require>
                        </div>

                        <div>
                            <!-- <button type="submit" name="btn-login" value="Login" class="btn primary" style="float: left;">Login</button> -->
                            <!-- <button type="submit" name="btn-login" class="btn btn-primary" name="submit" style="float: left;">Login</button> -->
                            <input type="submit" class="btn btn-primary" name="btn-login" value="login" style="float: left;">
                            <button type="button" class="btn btn-primary" id="forget" onclick="window.location.href='forget_password.php'">Forget Password</button>
                            <p class="login-register-text">Don't have an account ? <a href=" <?php echo base_url(); ?>Users/register">Register Here</a></p>

                        </div>
                    </form>
                </section>

            </div>

        </div>
    </div>
</body>

</html>