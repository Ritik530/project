
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-image: url(Css/back.jpeg);
            background-size: cover;
            background-attachment: local;
        }

        .container {
            background-color: blanchedalmond;
            width: 50%;
            padding: 40px;
            margin: 100px auto;
            color: black;

        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container md-4" id="div1">
        <h2>Please Register Here: </h2>
        <hr>
        
        <form class="form-col" action="<?php echo base_url();?>Users/register" name="registerform" method="post">
            <div class="form-row ">
                <div class="form-group col-md-6">
                    <label for="inputusername4">Username</label>
                    <input type="text" class="form-control" name="fld_admin_name" id="inputusername4" placeholder="username" required>

                </div>

                <div class="form-group col-md-6">
                    <label for="inputfullname4">Full Name</label>
                    <input type="text" class="form-control" name="ffld_name" id="inputfullname4" placeholder="fullname" required>

                </div>

                <div class="col-md-6">
                    <label for="inputEmail4" class="form-label">Email</label>
                    <input type="email" class="form-control" name="fld_email" id="inputEmail4" placeholder="email" required>
                </div>


                <div class="form-group col-md-6 ">
                    <label for="inputPassword4">Password</label>
                    <input type="password" class="form-control" name="fld_password" id="inputPassword4" placeholder="Password" required>
                </div>
                <div class="form-group col-md-6 ">
                    <label for="inputPassword4">Confirm Password</label>
                    <input type="password" class="form-control" name="confirm_password" id="inputPassword" placeholder="Confirm Password">
                </div>
            </div>
            <button type="submit" class="btn btn-primary" value="register"  name="submit">Sign in</button>
            <p class="login-register-text">Have an account? <a href="<?php echo base_url();?>Users">Login Here</a></p>
        </form>

    </div>

</body>

</html>