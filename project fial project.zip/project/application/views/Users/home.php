
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php base_url();?>Css/style1.css">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Htj.capital</title>

</head>

<script src="https://kit.fontawesome.com/d5f49a43ec.js" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<style>
   body {
    color: #eeeaea;
    background: #5cf8de;
    font-size: 17px;
    font-weight: 500;
    line-height: 1.471;
    font-family: Arial, Helvetica, sans-serif;
}
.div_main{
    width: 100%;
    height: 100%;
    /* background-color: aqua; */
    position: fixed;
}
.left_div{
    width: 13%;
    height: 100%;
    background-color: rgb(190, 74, 74);
    position: relative;
    float: left;
}

.main_head h2{
    color: white;
    font-size: 25px;
   padding-top: 12px;
   padding-bottom: 15px;
   padding-left: 20px;
    position: relative;
    background-color: rgb(40, 27, 78);

}
.right-div{
    width: 87%;
    height: 100%;
    position: relative;
    background-color: rgb(85, 85, 85);
    float: left;
}
.left-nav{
    width: 99.5%;
    height: 100%;
    position: relative;
    float: left;
}
.dropdown{
    background-color: rgb(149, 63, 175);
    color:rgb(255, 255, 255);
    font-size: 18px;
    /* padding-left: 0px; */
    margin-right: 7px;
    width: 120px;
    height: 53px;
    
    
    /* margin-left: 4px; */
    padding-top: 2px;
    padding-bottom: 5px;
}
.dropdown:hover{
    background: rgb(61, 60, 60);
}
.collapse {
    padding-left: 10px;
    font-size: 30px;
}
#navbarDropdown{
    color: aliceblue;
}
.left-name{
    background-color: white;
    margin-top: -10px;
    padding-top: 15px;
    padding-left: 40px;
    padding-bottom: 15px;

    /* padding: 20px; */
    color: #000000;

}
#navbarNav{
    color: #000000;
}
#navbarDropdow{
    color: black;
    background-color: rgb(238, 131, 241);
    padding-top: 17px;
    padding-left: 17px;
    padding-bottom: 11px;
}
*{
    margin: 0px;
    padding: 0px;
    user-select: none;
    box-sizing: border-box;
    font-family: 'Poppins',sans-serif;
}

.sidebar ul {
    /* padding-bottom: 16px; */
    font-size: 16px;
    background: white;
    height: 100%;
    width: 100%;
    list-style: none;
    padding-left: 0rem !important;
    

}

.sidebar ul li {
   
    line-height: 60px;
    border-top: 0px solid rgba(255, 255, 255, 0.1);
}
.sidebar ul li h1{
        font-size: 13px;
        padding: 18px;
        padding-left: 20px;
        display: block;
        font-weight: 500;
        color: white;
        background: #e8a6b2;
}
.sidebar ul li h1:hover{
    background: rgb(40, 27, 78);
}
.sidebar ul li h2{
    font-size: 13px;
    padding: 18px;
    padding-left: 20px;
    display: block;
    font-weight: 500;
    color: white;
    background: #1c25c8;
}
.sidebar ul li h2:hover{
    background: rgb(40, 27, 78);
}
.fa-regular{
    padding-right: 5px;
}

/* .sidebar ul li:last-child {
    border-bottom: 0px solid rgba(255, 255, 255, 0.05);
} */

.sidebar ul li a {
    margin-bottom: -10px;
    position: relative;
    color: rgb(255, 255, 255);
    text-decoration: none;
    font-size: 16px;
    /* padding-left: 40px; */
    font-weight: 500;
    display: block;
    width: 100%;
}
/* .mh{
    margin-bottom: -10px;
} */

.sidebar ul li.active a {
    /* color: cyan; */
    background: #524d4d;
    /* border-left-color: cyan; */
}

.sidebar ul li a:hover {
    background: #948f8f;
}

.sidebar ul ul {
    position: static;
    display: none;
}

.sidebar ul .feat-show.show {
    display: block;
}

.sidebar ul .serv-show.show1 {
    display: block;
}

.sidebar ul ul li {
    line-height: 42px;
}

.sidebar ul ul li a {
    background-color: rgb(255, 255, 255);
    font-size: 12px;
    color: #000000;
    padding-left: 50px;
    margin-top: -8px;
    padding-bottom: 10px;
    /* margin-bottom: 8px; */
}


.sidebar ul li.active ul li a {
    color: #000000;
    background-color: #6d6464;
    border-left-color: transparent;
}

.sidebar ul ul li a:hover {
    background: #adadad !important;
}


.sidebar ul li a span {
    position: absolute;
    top: 50%;
    right: 20px;
    transform: translateY(-50%);
    font-size: 22px;
    transition: transform 0.4s;
}


.sidebar ul li a span.rotate {
    transform: translateY(-50%) rotate(-180deg);
}






.menuc{
    background-color: rgb(208, 252, 47);
    position: relative;
    margin-top: -19px;
    display: block;
   
    
    
}
.menuc ul{
    

    list-style-type: none;
    padding-left: 0rem !important;

}
.menuc ul li a{
    padding-top: 10px;
    padding-left: 22px;
    padding-bottom: 15px;
    position: relative;
    color: white;
    text-decoration: none;
    font-size: 16px;

    font-weight: 500;
    /* padding-left: 40px; */
    font-weight: 500;
    display: block;
    width: 100%;

}
.menuc ul li a:hover{
    background: rgb(218, 219, 130);
    
    
   
}



</style>

<body>
    <div class="div_main">
        <div class="left_div">
            <div class="main_head">
                <a href="<?php echo base_url();?>Users/home" style="text-decoration: none;">
                    <h2><i class="fa-solid fa-paw"></i> HTJ.Capital</h2>
                </a>
                <div class="left-name">
                   Welcome,Admin
                </div>
                <div class="sidebar">
                    <ul>
                        <li class="mh">
                            <a  class="feat-btn">
                                <h1><i class="fa-regular fa-pen-to-square"></i> Premium Content</h1>
                                <span class="fas fa-angle-down first"></span>
                            </a>
                            <ul class="feat-show">
                                <li><a href="#">Manage Premium Content</a></li>
                                <li><a href="#">Add Premium Content</a></li>
                            </ul>
                        </li>
                        <li class="mg">
                            <a  class="serv-btn">
                                <h2><i class="fa-regular fa-pen-to-square"></i> Orders Management</h2>
                                <span class="fas fa-angle-down second"></span>
                            </a>
                            <ul class="serv-show">
                                <li><a href="#">Manage Orders</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
                <div class="menuc">
                    <ul>
                        <li><a class="dropdown-item" href="<?php echo base_url();?>Users/logout"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a></li>
                    </ul>
                </div>


            </div>








        </div>

        <div class="right-div">

            <div class="left-nav">
                <nav class="navbar navbar-expand-lg navbar-light bg-light" style="height: 57px;">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse mi-auto" id="navbarNav">
                        <i class="fa-solid fa-bars"></i>

                    </div>

                    <div class="dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Admin
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><a class="dropdown-item" href="<?php echo base_url();?>Users/logout">Logout </a></li>

                        </ul>
                    </div>
                </nav>

            </div>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script>
        $('.btn').click(function() {
            $(this).toggleClass("click");
            $('.sidebar ').toggleClass("show");
        });
        $('.feat-btn').click(function() {
            $('.sidebar ul .feat-show').toggleClass("show");
            $('.sidebar ul .first').toggleClass("rotate");
        });
        $('.serv-btn').click(function() {
            $('.sidebar ul .serv-show').toggleClass("show1");
            $('.sidebar ul .second').toggleClass("rotate");
        });
        $('sidebar ul li').click(function() {
            $(this).addClass("active").siblings().removeClass("active");
        });
    </script>
</body>

</html>