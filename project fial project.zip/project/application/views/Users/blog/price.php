<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Htj.capital</title>
</head>
<script src="https://kit.fontawesome.com/0483280171.js" crossorigin="anonymous"></script>
<style>
   
.body{
    color: black;
}
    .main_div {
        margin-top: -20px;
        border: 1px solid;
        padding: 10px 100px 15px 14px;
        
        background-color: #ECEFF8;
        width: 90%;
        height: 100%;
        position: fixed;
    }

 

    .menu {
        color: #73879C;
        font-size: 17px;
        width: 85%;
        height: 100%;
      
        background-color: rgb(219, 219, 219);
        position: fixed;
    }

    .home_div {
        color: black;

    }
    .menu{
        border: 1px solid;
        padding: 10px 10px 15px 20px;
        padding-right: 20px;
        /* margin: 10px;
        margin-right: 10px; */
    }
    .top_div{
        margin: 20px;
    }

    .paragraph {
        /* background-color: pink; */
        width: 80%;
        
        /* height: auto; */
        float: left;
    }


    .buttons {
        /* width: 20%; */
        float: left;
        text-align: end;
    }
    .manage_page_table{
        border: 1px solid;
        padding: 19px 10px 15px 20px;

        

      
    }
</style>

<body>


    <div class="main_div">
        <div class="home_div">
            <p><a href="#">Home</a><i class="fa-solid fa-angles-right"></i> Manage Orders</p>
            <div class="menu">
                <div class="top_div">
                    <div class="paragraph">
                        <p>Manage Orders</p>
                    </div>

                    <div class="buttons">
                        <button type="button" class="add_button"><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>

                <div class="table_div">
                    <table class="manage_page_table">
                        <tr style="background-color: blue;color:white;width:100%;">
                            <th style="width:2%;"><input type="checkbox" name="checkbox"> </th>
                            <th style="width:8%;">Order Date</th>
                            <th style="width:40%;">Name</th>
                            <th style="width:5%;">Price</th>
                            <th style="width:10%;">User Name</th>
                            <th style="width:15%;">Email</th>
                            <th style="width:10%;">Phone</th>
                            <th style="width:10%;">Status</th>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="checkbox"> </td>
                            <td>2020-11-02</td>
                            <td>Webinar for US Real Estate Investment for Investors from SE Asia</td>
                            <td>$39.99</td>
                            <td>Ryan Whitefield</td>
                            <td>gaa@gmail.com</td>
                            <td>+91 333666000</td>
                            <td>
                                <select>
                                    <option>Completed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><input type="checkbox" name="checkbox"> </td>
                            <td>2020-11-02</td>
                            <td>Webinar for US Real Estate Investment for Investors from SE Asia</td>
                            <td>$39.99</td>
                            <td>Ryan Whitefield</td>
                            <td>abcdefghijk@gmail.com</td>
                            <td>+91 088000000</td>
                            <td>
                                <select>
                                    <option>Completed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><input type="checkbox" name="checkbox"> </td>
                            <td>2020-11-02</td>
                            <td>Webinar for US Real Estate Investment for Investors from SE Asia</td>
                            <td>$39.99</td>
                            <td>Ryan Whitefield</td>
                            <td>abfghijk@gmail.com</td>
                            <td>+91 006880000</td>
                            <td>
                                <select>
                                    <option>Completed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><input type="checkbox" name="checkbox"> </td>
                            <td>2020-11-02</td>
                            <td>Webinar for US Real Estate Investment for Investors from SE Asia</td>
                            <td>$39.99</td>
                            <td>Ryan Whitefield</td>
                            <td>abfghijk@gmail.com</td>
                            <td>+91 0000000000</td>
                            <td>
                                <select>
                                    <option>Completed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><input type="checkbox" name="checkbox"> </td>
                            <td>2020-11-02</td>
                            <td>Webinar for US Real Estate Investment for Investors from SE Asia</td>
                            <td>$39.99</td>
                            <td>Ryan Whitefield</td>
                            <td>abfghijk@gmail.com</td>
                            <td>+91 0000000000</td>
                            <td>
                                <select>
                                    <option>Completed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><input type="checkbox" name="checkbox"> </td>
                            <td>2020-11-02</td>
                            <td>Webinar for US Real Estate Investment for Investors from SE Asia</td>
                            <td>$39.99</td>
                            <td>Ryan Whitefield</td>
                            <td>abcdefghijk@gmail.com</td>
                            <td>+91 0000000000</td>
                            <td>
                                <select>
                                    <option>Completed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td><input type="checkbox" name="checkbox"> </td>
                            <td>2020-11-02</td>
                            <td>Webinar for US Real Estate Investment for Investors from SE Asia</td>
                            <td>$39.99</td>
                            <td>Ryan Whitefield</td>
                            <td>abcdefghijk@gmail.com</td>
                            <td>+91 0000000000</td>
                            <td>
                                <select>
                                    <option>Completed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                </select>
                            </td>

                        </tr>
                    </table>

                </div>
            </div>
        </div>

    </div>
    <script>
        var checkboxes = document.querySelectorAll("input[type='checkbox']");
        function checkAll(myCheckbox){
            if(myCheckbox.checked == true){
                checkboxes.forEach(function(checkbox){
                    checkbox.checked= true;});
                
            }
            else{
                checkboxes.forEach(function(checkbox){
                    checkbox.checked= false;
                });
            }
        }
    </script>
</body>

</html>