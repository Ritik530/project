<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" />
    <title>Htj.capital</title>
</head>
<style>
    .div_main {
        color: #73879C;
    }

    .btn_div {
        width: 85%;
        background-color: #F7F7F7;
        border: 1px solid black;
        padding: 19px 10px 15px 20px;
        margin-left: 20px;
        text-align: "left";
    }

    .maindiv {
        width: 85%;
        margin-top: 9px;
        margin-bottom: 9px;
        margin-left: 20px;
        padding: 19px 10px 15px 20px;
        border: 1px solid black;

    }
</style>
<script>
    function validation() {
        var title = document.add_blog_form.add_blog_name.value;
        var price = document.add_blog_form.add_blog_price.value;
        var access = document.add_blog_form.access_select.value;
        var short_desc = document.add_blog_form.add_blog_short.value;
        var desc = document.add_blog_form.add_blog_pageedit.value;
        var image = document.add_blog_form.featured_image.value;

        if (title == null || title == '') {
            alert("Title is required");
            return false;
        } else if (price == null || price == '') {
            alert("Price is required");
            return false;
        } else if (access == null || access == '') {
            alert("Access Key is required");
            return false;
        } else if (short_desc == null || short_desc == '') {
            alert("Short Description is required");
            return false;
        } else if (desc == null || desc == '') {
            alert("Description is required");
            return false;
        } else if (image == null || image == '') {
            alert("Image is required");
            return false;
        } else {
            return true;
        }
    }
</script>

<body>



    <div class="div_main">
        <h2>Add Premium Content</h2>
        <div class="main_content_div">

            <form action="<?php echo base_url(); ?>Price/add_blog" method="post" enctype="multipart/form-data" onsubmit="return validation()" name="add_blog_form">

                <div class="btn_div" style="text-align:right;">
                    <input type="button" name="add_btn_cancel" value="cancel">
                    <input type="submit" name="add_btn_submit" value="Submit">
                </div>
                <div class="maindiv">

                    <h3>Personal Info</h3>


                    <div class="col-md-12 col-sm-8 col-xs-12">
                        <input name="add_blog_name" class="form-control col-md-7 col-xs-12" placeholder="Title" required="required" type="text">
                    </div>
                    <div class="col-md-12 col-sm-8 col-xs-12">
                        <input type="number" name="add_blog_price" class="form-control col-md-7 col-xs-12" placeholder="Price" required="required">
                    </div>
                    <div class="col-md-12 col-sm-8 col-xs-12">
                        <select required="required" class="form-control col-md-7 col-xs-12" name="access_select">
                            <option value="">-Select Access-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                        </select>
                    </div>
                    <div class="col-md-12 col-sm-8 col-xs-12">
                        <textarea placeholder="Short Description" class="form-control col-md-7 col-xs-12" name="add_blog_short" required="required"></textarea>
                    </div>
                    <div class="col-md-12 col-sm-8 col-xs-12">
                        <textarea name="add_blog_pageedit" class="form-control col-md-7 col-xs-12" placeholder="edit your page" required="required"></textarea>
                    </div><br>
                    <input type="file" name="image" id="before_crop_image" accept="images/*" required="required">featured image<br>
                    <div id="uploaded_image"></div>

                </div>
                <div class="btn_div" style="text-align:right;">

                    <input type="button" name="add_btn_cancel" value="cancel">
                    <input type="submit" name="add_btn_submit" value="Submit">
                </div>


            </form>
            <div id="imageModel" class="modal fade bd-example-modal-lg" role="dialog">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">×</button>
                            <h4 class="modal-title">Crop &amp; Resize Upload Image</h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-8 text-center">
                                    <div id="image_demo" style="width:450px; margin-top:30px"></div>
                                </div>
                                <div class="col-md-4" style="padding-top:30px;">
                                    <br >
                                    <br >
                                    <br >
                                    <button  class="btn btn-success crop_image" name="crop_image">Save</button>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal" id="cancel">Close</button>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

    <script>
        $(document).ready(function() {
            $image_crop = $('#image_demo').croppie({
                enableExif: true,
                viewport: {
                    width: 400,
                    height: 300,
                    type: 'square'
                },
                boundary: {
                    width: 500,
                    height: 400
                }
            });
            $('#cancel').click(() => {
                location.href = ''
            })
            $('#before_crop_image').on('change', function() {
                var reader = new FileReader();
                reader.onload = function(event) {
                    $image_crop.croppie('bind', {
                        url: event.target.result
                    }).then(function() {
                        console.log('jQuery bind complete');
                    });
                }
                reader.readAsDataURL(this.files[0]);
                $('#imageModel').modal('show');
            });
            $('.crop_image').click(function(event) {
                $image_crop.croppie('result', {
                    type: 'canvas',
                    size: 'viewport'
                }).then(function(response) {
                    $.ajax({
                        url: "<?= base_url(); ?>Price/add_blog/image",
                        type: 'POST',
                        data: {
                            "image": response
                        },

                        success: function(data) {

                            $('#imageModel').modal('hide');
                            alert('Crop image has been uploaded');
                        }
                    })
                });
            });
        });
    </script>


</body>


</html>