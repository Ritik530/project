<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Htj.capital</title>
</head>

<style>
    .button {
        width: 40px;
        height: 40px;
        border: none;
        border-radius: 5px;
        font-size: large;
        color: white;

    }

    .btn_add {
        background-color: skyblue;

    }

    .btn_dlt {
        background-color: red;

    }

    .btn_edit {
        background-color: skyblue;

    }


    .main_div {
        color: black;
        margin-top: -20px;
        border: 1px solid black;
        padding: 10px 10px 15px 14px;

        background-color: #ECEFF8;
        width: 100%;
        position: absolute;
    }


    .top_div {
        width: 97%;
        height: 100%;
        margin-left: 20px;
        border: 1px solid black;
        padding: 19px 10px 15px 20px;
        position: relative;
    }

    .heading {

        float: left;
    }

    .manage_div {

        width: 100%;
        height: 100%;
        margin-top: 10px;
        border: 1px solid black;
        padding: 19px 10px 15px 20px;
    }
</style>

<body>
    <div class="main_div">
        <p><a href="<?php echo base_url(); ?>Users/home">Home</a> » Manage Premium Content</p>
        <div class="top_div">




            <div class="heading">
                <?php if ($this->session->flashdata('status')) : ?>
                    <div class="alart alart-success">
                        <?= $this->session->flashdata('status'); ?>

                    </div>
                <?php endif; ?>
                <h2>Premium Content</h2>
            </div>
            <form action="<?= base_url('Price/delete_blog') ?>" method="POST" enctype="multipart/form-data">

                <div class="buttons" align="right">
                    <button type="button" name="add_button" class="button btn_add" onclick="window.location.href='<?php echo base_url(); ?>Price/add_blog'"><i class="fa-solid fa-plus"></i></button>
                    <button type="submit" name="delete_button" class="button btn-danger btn-sm" ><i class="fa-solid fa-trash-can"></i></button>
                </div>


                <div class="manage_div">

                    <table class="manage_page_table">

                        <th>
                            <tr style="background-color: blue; width:100%;color:white;">
                                <!-- <th>
                                    <button type="submit" name="delete_button" class="button btn-danger btn-sm">
                                        Delete All
                                    </button>

                                </th> -->
                                <th class="text-center" style="width: 5%;"><input type="checkbox" name="checkbox_value[]" value="checkbox" onchange="checkAll(this)"> </th>
                                <th  class="text-center" style="width: 7%;">ID</th>
                                <th  class="text-center" style="width: 70%;">Name</th>
                                <th  class="text-center" style="width: 20%;">Image</th>
                                <th  class="text-center" style="width: 20%;">Edit</th>
                                <!-- <th style="width: 10%;">Delete</th> -->
                            </tr>
                        </th>

                        <tr>

                            <?php
                            for ($i = 0; $i < sizeof($table_data); $i++) { ?>

                        <tr>

                            <td  class="text-center" style="width:5%;"><input type="checkbox" name="checkbox_value[]" value="<?php echo $table_data[$i]->fld_id; ?>"> </td>
                            <td class="text-center"  style="width: 7%;"><?php echo $table_data[$i]->fld_id; ?></td>
                          
                            <td class="text-center" style="width:65%;"><?php echo $table_data[$i]->fld_title; ?></td>
                            <td class="text-center" style="width:20%;"><img src="<?php echo base_url();?>images/<?php echo $table_data[$i]->fld_image; ?>" width="100px" height="50px" style="border-radius:5px;"></td>
                            <td class="text-center" style="width:20%;"><button type="button" value="" name="add_button" class="button btn_edit" onclick="window.location.href='<?php echo base_url(); ?>Price/edit_blog/<?php echo $table_data[$i]->fld_id; ?>'"><i class="fa-solid fa-pen-to-square"></i></button></td>
                          
                        </tr>
                       

                    <?php } ?>
                    </tr>

                    </table>

                </div>
            
            </form>
        </div>


    </div>
    <script>
        var checkboxes = document.querySelectorAll("input[type='checkbox']");

        function checkAll(myCheckbox) {
            if (myCheckbox.checked == true) {
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = true;
                });

            } else {
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = false;
                });
            }
        }
    </script>

</body>

</html>