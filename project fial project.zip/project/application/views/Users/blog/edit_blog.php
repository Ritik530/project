<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Htj.capital</title>
</head>
<style>
    .div_main {
        color: #73879C;
    }

    /* .btn_div {
        width: 80%;
        background-color: red;
        text-align: end;
        padding: 10px;
    } */
    .btn_div {
        width: 85%;
        background-color: #F7F7F7;
        border: 1px solid black;
        padding: 19px 10px 15px 20px;
        margin-left: 20px;
        text-align: "left";
    }

    .maindiv {
        width: 85%;
        margin-top: 9px;
        margin-bottom: 9px;
        margin-left: 20px;
        padding: 19px 10px 15px 20px;
        border: 1px solid black;

    }
</style>

<body>
    <div class="div_main">
        <h2>Edit Page</h2>

        <form action="<?php echo base_url(); ?>Price/updatepage/<?= $page_info[0]->fld_id ?>" method="post" enctype="multipart/form-data">
            <div class="btn_div" style="text-align:right;">

                <input type="submit" name="edit_blog_cancel" value="cancel">
                <input type="submit" name="edit_blog_submit" value="Submit">
            </div>
            <div class="maindiv">
                <h2>Personal Info</h2>

                <input type="text" class="form-control col-md-7 col-xs-12" name="edit_blog_name" placeholder="Name" value="<?= $page_info[0]->fld_title ?>">

                <input type="number" class="form-control col-md-7 col-xs-12" name="edit_blog_price" placeholder="Price" value="<?= $page_info[0]->price ?>">

                <select class="form-control col-md-7 col-xs-12" name="access_select">
                    <option><?= $page_info[0]->access ?></option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                <textarea name="edit_blog_short_description" class="form-control col-md-7 col-xs-12" placeholder="Short Description"><?= $page_info[0]->shortdescription ?></textarea>
                <textarea name="edit_blog_description" class="form-control col-md-7 col-xs-12" placeholder="edit your page"><?= $page_info[0]->fld_description ?></textarea><br>
                <img src="<?php echo base_url();?>images/<?= $page_info[0]->fld_image ?>" alt="" width="150px" height="auto" ><br>
                <input type="file" name="img">
            </div>
            <div class="btn_div" style="text-align:right;">
                <input type="submit" name="edit_blog_cancel" value="cancel">
                <input type="submit" name="edit_blog_submit" value="Submit">
            </div>
          


           

        </form>




    </div>

</body>

</html>