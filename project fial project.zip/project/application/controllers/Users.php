<?php

defined('BASEPATH') or exit('No direct script access allowed');


class Users extends CI_controller
{


    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('loginmodel');
    }


    public function index()
    {
        $this->load->view("users/login");
    }

    public function home()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('mail', 'Email id', 'required');
        $this->form_validation->set_rules('pass', 'Password', 'required');
        $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

        if ($this->form_validation->run()) {
            $mail = $this->input->post('mail');
            $_SESSION['name'] = $mail;
            $pass = $this->input->post('pass');
            $this->load->model('loginmodel');
            if(isset($_SESSION['name'])){

                $data['admin_data']=$this->loginmodel->validate($mail);
                $_SESSION['fld_admin_name'] = $data['admin_data']['0'] -> fld_admin_name;
            }
            if ($this->loginmodel->isvalidate($mail, $pass)) {
                $data['page'] = 'includes/main_content';
                $this->load->view("includes/home", $data);
            } else {
                $this->load->view("Users/login");
            }
        } else {
            $this->load->view("Users/login");
        }
   

}
    public function register()
    {
        $this->load->view("Users/register");
    }

    public function login()
    {
        $this->load->view("Users/login");
    }
    public function price()
    {
        $data['page'] = 'Users/blog/price';
        $this->load->view("includes/home",$data);
    }



    public function logout()
    {
        session_destroy();
        header("Location: ".base_url().'Users');
    }
}
