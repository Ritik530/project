<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Price extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('Adminmodel');
        $this->load->library('session');
    }

    public function page()
    {

        $data['table_data'] = $this->Adminmodel->fetch_data();

        $data['page'] = 'Users/blog/page';
        $this->load->view("includes/home", $data);
    }
    public function add_blog()
    {
     
        // $id = "";
        
      
        // $this->load->model('Adminmodel');
        // $id_value = $this->Adminmodel->upload_image($id);

  



        if ($this->input->post('add_btn_submit') == 'Submit') {

            $this->load->model('Adminmodel');
            $this->Adminmodel->dataInsert();
            $data['table_data'] = $this->Adminmodel->fetch_data();


            $data['page'] = 'Users/blog/page';
            $this->load->view("includes/home", $data);
        } else {

            $data['page'] = 'Users/blog/add_blog';
            $this->load->view("includes/home", $data);
        }
    }
//     public function upload_image()
//     {
        
       
//                     $this->load->model('Adminmodel');
//                     $this->Adminmodel->upload_image();
//                     $data['table_data'] = $this->Adminmodel->fetch_data();
    
    
//                     $data['page'] = 'Users/blog/add_blog';
//                     $this->load->view("includes/home", $data);
    
// }
        
        

        // $builder = $db->table('crop_images');
        // $imgblob = $this->input->post('image');
        // // echo $imgblob;
        // $remove_type = explode(";", $imgblob);
        // // echo $remove_type[1];
        // $remove_base = explode(",", $remove_type[1]);
        // $final_data = $remove_base[1];
        // $final_data_de = base64_decode($final_data);
        // $image = time() . '.png';
        // file_put_contents("images/" . $image, $final_data_de);



      


        // if(isset($_POST['image'])){
        //     $data = $_POST["image"];
        //     $image_array_1 = explode(";", $data);
        //     $image_array_2 = explode(",", $image_array_1[1]);
        //     $basedecoder = base64_decode($image_array_2[1]);
        //     $imageaa = time() . '.jpg';
        //     file_put_contents("images/".$imageaa,$basedecoder );


        // }






        //     $imgblob = $this->input->post('image');
        //     // echo $imgblob;
        //     $remove_type= explode(";",$imgblob);
        //     // echo $remove_type[1];
        //     $remove_base = explode(",",$remove_type[1]);
        //   $final_data=$remove_base[1];
        //   $final_data_de=base64_decode($final_data);
        //    $image=time().'.png';
        //    file_put_contents("images/".$image,$final_data_de);
      

        //     if ($this->input->post('image_btn_submit') == 'Submit') {

        //         $this->load->model('Adminmodel');
        //         $this->Adminmodel->upload_image();
        //         $data['table_data'] = $this->Adminmodel->fetch_data();


        //         $data['page'] = 'Users/blog/add_blog';
        //         $this->load->view("includes/home", $data);

        // }
    // }


    public function updatepage()
    {

        if ($this->input->post('edit_blog_submit') == 'Submit') {

            $id = $this->uri->segment('3');

            $this->Adminmodel->update_data($id);
            $data['table_data'] = $this->Adminmodel->fetch_data();

            $data['page'] = 'Users/blog/page';

            $this->load->view("includes/home", $data);
        }
    }



    public function edit_blog()

    {

        $pageid = $this->uri->segment('3');


        $data['page_info'] = $this->Adminmodel->edit_blo($pageid);
        $data['page'] = 'Users/blog/edit_blog';

        $this->load->view('includes/home', $data);

        //    echo "<pre>";
        //    print_r($data['page_info']);	
    }






    public function delete_blog()
    {
        if (isset($_POST['delete_button'])) {

            if (!empty($this->input->post('checkbox_value'))) {
                $checkedEmp = $this->input->post('checkbox_value');
                // echo $checkedEmp;
                $checked_id = [];
                foreach ($checkedEmp as $row) {
                    //    echo $row;
                    array_push($checked_id, $row);
                }
                $this->load->model('Adminmodel');
                $this->Adminmodel->delete_blo($checked_id);


                $data['table_data'] = $this->Adminmodel->fetch_data();

                $data['page'] = 'Users/blog/page';
                $this->load->view("includes/home", $data);
            }
        } else {
            // redirect(base_url('Users/blog/page'));
            $data['page'] = 'Users/blog/page';
            $this->load->view("includes/home", $data);
        }
    }
}
