<?php
defined('basepath') or exit('no direct script access allowed');

class welcome extends ci_controller {
    
    function __construct() {
        parent::__construct();
        
        $this->load->library('upload');
        $this->load->library('image_lib');
        
    }

	public function index()
	{
		$this->load->view('welcome_message');
	}
        
        function imageedit() {
            
        $config['upload_path'] = './images/product/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['file_name'] = str_replace('_', '', str_replace(' ', '', strtolower($_files['editimage']['name'])));
        $this->upload->initialize($config);
        $this->upload->do_upload('editimage');
        $data = array(
            'image' => $config['file_name']
        );

        $path = './images/product/' . str_replace('_', '', str_replace(' ', '', strtolower($_files['editimage']['name'])));

        $upload_data = $this->upload->data();
        $upload_img_data = getimagesize($upload_data['full_path']);
        $water_mark = "";
        $configrez['image_library'] = 'gd2';
        $configrez['source_image'] = $path;
        $configrez['create_thumb'] = false;
        $configrez['maintain_ratio'] = false;
        
        if ($upload_img_data[0] > $upload_img_data[1]) {
            
            $configrez['width'] = $upload_img_data[1];
            $configrez['height'] = $upload_img_data[1];
            $configrez['x_axis'] = ($upload_img_data[0] - $upload_img_data[1]) / 2;
            $configrez['y_axis'] = 0;
            $water_mark = $upload_img_data[1];
            
        } else {
            
            $configrez['width'] = $upload_img_data[0];
            $configrez['height'] = $upload_img_data[0];
            $configrez['x_axis'] = 0;
            $configrez['y_axis'] = ($upload_img_data[1] - $upload_img_data[0]) / 2;
            $water_mark = $upload_img_data[0];
            
        }
        $this->image_lib->initialize($configrez);
        $this->image_lib->crop();

        $configrez2['image_library'] = 'gd2';
        $configrez2['source_image'] = $path;
        $configrez2['create_thumb'] = false;
        $configrez2['maintain_ratio'] = false;
        $configrez2['width'] = "800";
        $configrez2['height'] = "800";
        $this->image_lib->initialize($configrez2);
        $this->image_lib->resize();

        $configwm['source_image'] = $path;
        $configwm['wm_overlay_path'] = './images/watermark.png';
        $configwm['wm_type'] = 'overlay';
        $configwm['wm_opacity'] = '100';
        $configwm['wm_vrt_alignment'] = 'middle';
        $configwm['wm_hor_alignment'] = 'center';
        $this->image_lib->initialize($configwm);
        $this->image_lib->watermark();
        
        echo 'successfuly uploaded';
                
    }
}
?>