<?php
class admin extends CI_controller
{
    public function home()
    {
        // $this->load->view("Users/home");
    }
    
    
}
