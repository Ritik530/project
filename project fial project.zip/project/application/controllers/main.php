<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Adminmodel');
		$this->load->database();
	}
	
	public function index()
	{
		$data['table_data'] = $this->Adminmodel->fetch_data();  
		$this->load->view('frontpage',$data);
	
		
	}
}